# Carrom Aim Assistant (Android)

A free, offline Android Studio starter app. It loads a screenshot and lets you manually mark the striker, target coin, pocket and other coins. It draws a ghost-ball aiming line and reports geometric distances/angles.

## Build an APK
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this project folder (`CarromAimAssistant`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy that APK to your phone, tap it, allow installation from that file manager if Android asks, then install.

## Use
1. Tap Load game screenshot and choose a screenshot from the game.
2. Tap Striker, then tap the centre of your striker.
3. Tap Target, then tap the centre of the coin you want to pot.
4. Tap Pocket, then tap the centre of the intended pocket.
5. Optionally tap Add coin and mark coins that may obstruct the direct striker-to-ghost-ball line.
6. Tap Calculate Best Shot. Yellow is the striker-to-ghost-ball aim line; green is target-to-pocket; cyan is the ghost-ball contact segment; magenta dashed lines are rough reflected-path guides.

## Important limitations
- This starter uses manual screenshot marking; it does not automatically recognize every coin or control the game.
- The displayed geometry is an estimate. The coin-radius assumption is 1.8% of screenshot width and may need calibration for your game resolution/zoom.
- It does not read game memory, automate taps, guarantee a successful shot, or bypass game protections.
- The magenta bank guides are visual candidate guides, not a complete collision/rail-physics solver. Game-specific physics, spin, friction, striker placement limits and collision restitution need calibration from measured gameplay.
- No account, network access, ads, paid SDK or subscription is required.
